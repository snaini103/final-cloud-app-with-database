# final-cloud-app-with-database
 A cloud-hosted exam app programmed with Django and Python - final project for a course on Coursera going towards the IBM Full Stack Software Developer Professional Certificate
